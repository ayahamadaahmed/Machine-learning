import streamlit as st
import pickle
import numpy as np

# Load model
with open('random_forest_model.pkl', 'rb') as f:
    model = pickle.load(f)

# Page settings
st.set_page_config(page_title="Iris Classifier", page_icon="🌸", layout="centered")

# 🌸 Custom CSS Styling
st.markdown("""
    <style>
    .stApp {
        background-image: url("https://images.unsplash.com/photo-1506744038136-46273834b3fb");
        background-size: cover;
        background-repeat: no-repeat;
        background-attachment: fixed;
        color: #ffffff;
    }

    .main {
        background-color: rgba(255, 255, 255, 0.1);
        padding: 2rem;
        border-radius: 1rem;
        backdrop-filter: blur(6px);
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    }

    .title {
        text-align: center;
        color: #ffffff;
        font-size: 2.5rem;
        font-weight: bold;
        margin-bottom: 2rem;
        text-shadow: 1px 1px 2px black;
    }

    .stButton>button {
        background-color: #2E86C1;
        color: white;
        font-weight: bold;
        border-radius: 8px;
        padding: 0.5rem 1rem;
    }

    .stNumberInput label {
        font-weight: bold;
        color: #ffffff;
        text-shadow: 1px 1px 2px black;
    }
    </style>
""", unsafe_allow_html=True)

# 🌸 Title
st.markdown("<h1 class='title'>🌸 Iris Flower Classifier</h1>", unsafe_allow_html=True)

# 🌸 Input Section
with st.container():
    st.markdown("<div class='main'>", unsafe_allow_html=True)

    st.subheader("Enter flower measurements:")

    col1, col2 = st.columns(2)
    with col1:
        sepal_length = st.number_input("Sepal Length (cm)", 4.0, 8.0, 5.1)
        petal_length = st.number_input("Petal Length (cm)", 1.0, 7.0, 1.4)

    with col2:
        sepal_width = st.number_input("Sepal Width (cm)", 2.0, 4.5, 3.5)
        petal_width = st.number_input("Petal Width (cm)", 0.1, 2.5, 0.2)

    # 🌸 Predict Button
    if st.button("🔍 Predict"):
        input_data = np.array([[sepal_length, sepal_width, petal_length, petal_width]])
        prediction = model.predict(input_data)[0]
        classes = ['Setosa', 'Versicolor', 'Virginica']
        st.success(f"🌼 Predicted Iris Class: **{classes[prediction]}**")

    st.markdown("</div>", unsafe_allow_html=True)
