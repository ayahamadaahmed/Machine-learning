# main.py
import tkinter as tk
from tkinter import ttk
import database     # ensure database.init_db() is called before GUI starts
from home import HomeFrame
from booking import BookingFrame
from reservations import ReservationsFrame
from edit_reservation import EditReservationFrame

APP_TITLE = "Flight Reservation App"
APP_SIZE = "900x520"

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry(APP_SIZE)
        self.minsize(820, 480)

        # container where pages (frames) will be stacked
        container = ttk.Frame(self)
        container.pack(fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}
        for FrameClass, name in [
            (HomeFrame, "HomeFrame"),
            (BookingFrame, "BookingFrame"),
            (ReservationsFrame, "ReservationsFrame"),
            (EditReservationFrame, "EditReservationFrame"),
        ]:
            frame = FrameClass(container, self)
            self.frames[name] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame("HomeFrame")

    def show_frame(self, name: str):
        frame = self.frames[name]
        # If frames implement 'refresh', call it so list pages can reload data.
        if hasattr(frame, "refresh"):
            try:
                frame.refresh()
            except Exception:
                pass
        frame.tkraise()

if __name__ == "__main__":
    database.init_db()
    app = App()
    app.mainloop()

