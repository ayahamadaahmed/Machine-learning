# database.py
import sqlite3
from contextlib import closing

DB_PATH = "flights.db"

def get_connection():
    """Return a sqlite3 connection with Row factory for dict-like access."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Create the reservations table if it does not exist."""
    with closing(get_connection()) as conn, conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS reservations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                flight_number TEXT NOT NULL,
                departure TEXT NOT NULL,
                destination TEXT NOT NULL,
                date TEXT NOT NULL,
                seat_number TEXT NOT NULL
            );
            """
        )

def add_reservation(name, flight_number, departure, destination, date, seat_number):
    """Insert a new reservation and return the new row id."""
    with closing(get_connection()) as conn, conn:
        cur = conn.execute(
            """
            INSERT INTO reservations (name, flight_number, departure, destination, date, seat_number)
            VALUES (?, ?, ?, ?, ?, ?);
            """,
            (name, flight_number, departure, destination, date, seat_number),
        )
        return cur.lastrowid

def get_reservations():
    """Return a list of all reservations as dictionaries."""
    with closing(get_connection()) as conn:
        cur = conn.execute("SELECT * FROM reservations ORDER BY date ASC, id DESC;")
        return [dict(row) for row in cur.fetchall()]

def get_reservation_by_id(res_id: int):
    """Return a single reservation by id or None."""
    with closing(get_connection()) as conn:
        cur = conn.execute("SELECT * FROM reservations WHERE id = ?;", (res_id,))
        row = cur.fetchone()
        return dict(row) if row else None

def update_reservation(res_id, name, flight_number, departure, destination, date, seat_number):
    """Update a reservation row by id."""
    with closing(get_connection()) as conn, conn:
        conn.execute(
            """
            UPDATE reservations
               SET name=?, flight_number=?, departure=?, destination=?, date=?, seat_number=?
             WHERE id=?;
            """,
            (name, flight_number, departure, destination, date, seat_number, res_id),
        )

def delete_reservation(res_id: int):
    """Delete a reservation by id."""
    with closing(get_connection()) as conn, conn:
        conn.execute("DELETE FROM reservations WHERE id = ?;", (res_id,))
