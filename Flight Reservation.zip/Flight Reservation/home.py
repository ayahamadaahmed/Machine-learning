# home.py
import tkinter as tk
from tkinter import ttk

class HomeFrame(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, padding=20)
        self.controller = controller

        title = ttk.Label(self, text="✈️ Flight Reservation System", font=("Segoe UI", 18, "bold"))
        subtitle = ttk.Label(self, text="Welcome! Choose an option to get started.", font=("Segoe UI", 11))

        btn_book = ttk.Button(self, text="Book Flight", command=lambda: controller.show_frame("BookingFrame"))
        btn_view = ttk.Button(self, text="View Reservations", command=lambda: controller.show_frame("ReservationsFrame"))

        title.grid(row=0, column=0, columnspan=2, pady=(0, 8))
        subtitle.grid(row=1, column=0, columnspan=2, pady=(0, 20))

        btn_book.grid(row=2, column=0, padx=8, pady=8, sticky="ew")
        btn_view.grid(row=2, column=1, padx=8, pady=8, sticky="ew")

        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)
