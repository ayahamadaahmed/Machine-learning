
import tkinter as tk
from tkinter import ttk, messagebox
import database

class EditReservationFrame(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, padding=20)
        self.controller = controller
        self.current_id = None

        title = ttk.Label(self, text="Edit Reservation", font=("Segoe UI", 16, "bold"))
        title.grid(row=0, column=0, columnspan=2, pady=(0, 12))

        self.inputs = {}
        fields = [
            ("name", "Passenger Name"),
            ("flight_number", "Flight Number"),
            ("departure", "Departure"),
            ("destination", "Destination"),
            ("date", "Date (YYYY-MM-DD)"),
            ("seat_number", "Seat Number"),
        ]

        for i, (key, label) in enumerate(fields, start=1):
            ttk.Label(self, text=label).grid(row=i, column=0, sticky="e", padx=(0, 8), pady=6)
            entry = ttk.Entry(self, width=30)
            entry.grid(row=i, column=1, sticky="w", pady=6)
            self.inputs[key] = entry

        btn_frame = ttk.Frame(self)
        btn_frame.grid(row=len(fields)+1, column=0, columnspan=2, pady=12, sticky="ew")
        btn_update = ttk.Button(btn_frame, text="Update", command=self.update)
        btn_delete = ttk.Button(btn_frame, text="Delete", command=self.delete)
        btn_back = ttk.Button(btn_frame, text="⬅ Back", command=lambda: self.controller.show_frame("ReservationsFrame"))
        btn_update.pack(side="left", padx=4)
        btn_delete.pack(side="left", padx=4)
        btn_back.pack(side="right", padx=4)

        for c in range(2):
            self.columnconfigure(c, weight=1)

    def set_reservation(self, res_id: int):
        self.current_id = res_id
        data = database.get_reservation_by_id(res_id)
        if not data:
            messagebox.showerror("Not found", "Reservation not found.")
            self.controller.show_frame("ReservationsFrame")
            return
        for k, entry in self.inputs.items():
            entry.delete(0, "end")
            entry.insert(0, data.get(k, ""))

    def update(self):
        if self.current_id is None:
            return
        values = {k: e.get().strip() for k, e in self.inputs.items()}
        if not all(values.values()):
            messagebox.showerror("Validation error", "Please fill in all fields.")
            return
        try:
            database.update_reservation(
                self.current_id,
                values["name"],
                values["flight_number"],
                values["departure"],
                values["destination"],
                values["date"],
                values["seat_number"],
            )
            messagebox.showinfo("Updated", "Reservation updated successfully.")
            self.controller.show_frame("ReservationsFrame")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to update reservation:\n{e}")

    def delete(self):
        if self.current_id is None:
            return
        if not messagebox.askyesno("Confirm delete", "Are you sure you want to delete this reservation?"):
            return
        try:
            database.delete_reservation(self.current_id)
            messagebox.showinfo("Deleted", "Reservation deleted.")
            self.controller.show_frame("ReservationsFrame")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to delete reservation:\n{e}")
