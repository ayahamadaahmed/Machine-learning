
import tkinter as tk
from tkinter import ttk, messagebox
import database

class ReservationsFrame(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, padding=20)
        self.controller = controller

        header = ttk.Frame(self)
        header.pack(fill="x", pady=(0,10))

        title = ttk.Label(header, text="Reservations", font=("Segoe UI", 16, "bold"))
        title.pack(side="left")

        btns = ttk.Frame(header)
        btns.pack(side="right")
        ttk.Button(btns, text="➕ New", command=lambda: controller.show_frame("BookingFrame")).pack(side="left", padx=4)
        ttk.Button(btns, text="⟳ Refresh", command=self.refresh).pack(side="left", padx=4)
        ttk.Button(btns, text="⬅ Home", command=lambda: controller.show_frame("HomeFrame")).pack(side="left", padx=4)

        cols = ("id", "name", "flight_number", "departure", "destination", "date", "seat_number")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=12)
        for c in cols:
            self.tree.heading(c, text=c.replace("_", " ").title())
            self.tree.column(c, anchor="center")
        self.tree.pack(fill="both", expand=True)

        footer = ttk.Frame(self)
        footer.pack(fill="x", pady=(10,0))
        ttk.Button(footer, text="Edit Selected", command=self.edit_selected).pack(side="left", padx=4)
        ttk.Button(footer, text="Delete Selected", command=self.delete_selected).pack(side="left", padx=4)

        self.refresh()

    def refresh(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        try:
            rows = database.get_reservations()
            for r in rows:
                self.tree.insert("", "end", values=(r["id"], r["name"], r["flight_number"], r["departure"], r["destination"], r["date"], r["seat_number"]))
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load reservations:\n{e}")

    def get_selected_id(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showwarning("No selection", "Please select a reservation first.")
            return None
        values = self.tree.item(sel[0], "values")
        return int(values[0])

    def edit_selected(self):
        res_id = self.get_selected_id()
        if res_id is None:
            return
        self.controller.frames["EditReservationFrame"].set_reservation(res_id)
        self.controller.show_frame("EditReservationFrame")

    def delete_selected(self):
        res_id = self.get_selected_id()
        if res_id is None:
            return
        if not messagebox.askyesno("Confirm delete", "Are you sure you want to delete this reservation?"):
            return
        try:
            database.delete_reservation(res_id)
            self.refresh()
            messagebox.showinfo("Deleted", "Reservation deleted.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to delete reservation:\n{e}")
