# booking.py
import tkinter as tk
from tkinter import ttk, messagebox
import database

class BookingFrame(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, padding=20)
        self.controller = controller

        title = ttk.Label(self, text="Book a Flight", font=("Segoe UI", 16, "bold"))
        title.grid(row=0, column=0, columnspan=2, pady=(0, 12))

        self.inputs = {}
        fields = [
            ("name", "Passenger Name"),
            ("flight_number", "Flight Number"),
            ("departure", "Departure"),
            ("destination", "Destination"),
            ("date", "Date (YYYY-MM-DD)"),
            ("seat_number", "Seat Number"),
        ]

        for i, (key, label) in enumerate(fields, start=1):
            ttk.Label(self, text=label).grid(row=i, column=0, sticky="e", padx=(0, 8), pady=6)
            entry = ttk.Entry(self, width=30)
            entry.grid(row=i, column=1, sticky="w", pady=6)
            self.inputs[key] = entry

        btn_frame = ttk.Frame(self)
        btn_frame.grid(row=len(fields)+1, column=0, columnspan=2, pady=12, sticky="ew")
        btn_submit = ttk.Button(btn_frame, text="Submit", command=self.submit)
        btn_clear = ttk.Button(btn_frame, text="Clear", command=self.clear_form)
        btn_back = ttk.Button(btn_frame, text="⬅ Back", command=lambda: self.controller.show_frame("HomeFrame"))
        btn_submit.pack(side="left", padx=4)
        btn_clear.pack(side="left", padx=4)
        btn_back.pack(side="right", padx=4)

        for c in range(2):
            self.columnconfigure(c, weight=1)

    def clear_form(self):
        for e in self.inputs.values():
            e.delete(0, "end")

    def submit(self):
        values = {k: e.get().strip() for k, e in self.inputs.items()}
        # Basic validation
        if not all(values.values()):
            messagebox.showerror("Validation error", "Please fill in all fields.")
            return
        # Save to database
        try:
            database.add_reservation(
                values["name"],
                values["flight_number"],
                values["departure"],
                values["destination"],
                values["date"],
                values["seat_number"],
            )
            messagebox.showinfo("Success", "Reservation saved successfully.")
            self.clear_form()
            self.controller.show_frame("ReservationsFrame")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save reservation:\n{e}")
